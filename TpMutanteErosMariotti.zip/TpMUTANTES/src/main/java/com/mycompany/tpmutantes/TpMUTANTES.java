/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tpmutantes;

/**
 *
 * @author Usuario
 */
public class TpMUTANTES {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
