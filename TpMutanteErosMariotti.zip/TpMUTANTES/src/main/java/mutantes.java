



public class mutantes {

    public static boolean isMutant(String[] dna) {
        int filas = dna.length;
        int columnas = dna[0].length();

        // Verificar horizontal
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j <= columnas - 4; j++) {
                if (dna[i].charAt(j) == dna[i].charAt(j + 1) &&
                    dna[i].charAt(j) == dna[i].charAt(j + 2) &&
                    dna[i].charAt(j) == dna[i].charAt(j + 3)) {
                    return true;
                }
            }
        }

        // Verificar vertical
        for (int i = 0; i <= filas - 4; i++) {
            for (int j = 0; j < columnas; j++) {
                if (dna[i].charAt(j) == dna[i + 1].charAt(j) &&
                    dna[i].charAt(j) == dna[i + 2].charAt(j) &&
                    dna[i].charAt(j) == dna[i + 3].charAt(j)) {
                    return true;
                }
            }
        }

        // Verificar diagonal principal (de izquierda a derecha)
        for (int i = 0; i <= filas - 4; i++) {
            for (int j = 0; j <= columnas - 4; j++) {
                if (dna[i].charAt(j) == dna[i + 1].charAt(j + 1) &&
                    dna[i].charAt(j) == dna[i + 2].charAt(j + 2) &&
                    dna[i].charAt(j) == dna[i + 3].charAt(j + 3)) {
                    return true;
                }
            }
        }

        // Verificar diagonal inversa (de derecha a izquierda)
        for (int i = 0; i <= filas - 4; i++) {
            for (int j = 3; j < columnas; j++) {
                if (dna[i].charAt(j) == dna[i + 1].charAt(j - 1) &&
                    dna[i].charAt(j) == dna[i + 2].charAt(j - 2) &&
                    dna[i].charAt(j) == dna[i + 3].charAt(j - 3)) {
                    return true;
                }
            }
        }

        // Si no se encontraron secuencias mutantes, retornamos false.
        return false;
    }
    
    
    public static void main(String[] args) {
        
        String[] dnaMutant = {"ATGCGA","CAGTGC","TTATGT","AGAAGG","CCCCTA","TCACTG"};
        
        String[] dnaNoMutante = {"ATGCGA", "CAGTGC", "TTATTT", "AGACGG", "GCGTCA", "TCACTG"};
        
        
        System.out.println("Caso 1 - ADN Mutante:");
        for (String row : dnaMutant) {
            System.out.println(row);
        }
        
        System.out.println("\nCaso 2 - ADN No Mutante:");
        for (String row : dnaNoMutante) {
            System.out.println(row);
        }
        
        System.out.println("Vamos a verificar si eres mutante,,,");
        
        if (isMutant(dnaMutant)){
            System.out.println("Caso 1: Eres Mutante.");
        } else {
            System.out.println("Caso 1: No eres Mutante.");
        }
        
        if (isMutant(dnaNoMutante)){
            System.out.println("Caso 2: Eres Mutante.");
        } else {
            System.out.println("Caso 2: No eres Mutante.");
        }   
    }
    
}
